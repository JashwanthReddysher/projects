package com.tsc.boot.entity;
import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "Teacher")
public class TeacherEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "userId", referencedColumnName = "userId", nullable = false)
	private UserEntity userId;

	@Column(name = "specialization", length = 40)
	private String specialization;
	@Column(name="proficiency",length=40)
	private String proficiency;
	@Column(name="remarks",length=50)
	private String remarks;
	
	
	public String getProficiency() {
		return proficiency;
	}

	public void setProficiency(String proficiency) {
		this.proficiency = proficiency;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public UserEntity getUserId() {
		return userId;
	}

	public void setUserId(UserEntity userId) {
		this.userId = userId;
	}
	@Override
    public int hashCode() {
        return Objects.hashCode(userId);
    }
 
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TeacherEntity other = (TeacherEntity) obj;
        return Objects.equals(userId, other.getUserId());
    }

	public TeacherEntity(UserEntity userId, String specialization, String proficiency, String remarks) {
		super();
		this.userId = userId;
		this.specialization = specialization;
		this.proficiency = proficiency;
		this.remarks = remarks;
	}

	public TeacherEntity() {
		super();
	}
    
}
