package com.cts.authenticationservice.services;

import com.cts.authenticationservice.entities.ApplicationUser;
import com.cts.authenticationservice.repository.UserRepository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService{
    private UserRepository userRepository;

    public AuthServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public boolean validate(String userName, String password) {
        boolean b=false;
        ApplicationUser user=userRepository.findByUserNameAndPassword(userName,password);
        if(user!=null)
            b=true;
        return b;
    }

	@Override
	public List<ApplicationUser> allUsers() {
		List<ApplicationUser> users=new ArrayList<ApplicationUser>();
		for(ApplicationUser u:userRepository.findAll()) {
			users.add(u);
		}
		return users;
	}
}
