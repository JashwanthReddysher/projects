package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Cart;
import com.cognizant.repository.CartRepository;

@Service
@Transactional
public class CartService {
	
	@Autowired
	private CartRepository cartRepository;

	public CartService(CartRepository cartRepository) {
		super();
		this.cartRepository = cartRepository;
	}
	
	public List<Cart> getCartItems(int userId){
		List<Cart> carts = new ArrayList<Cart>();
		for(Cart cart : cartRepository.getCartItems(userId)) {
			carts.add(cart);
		}
		
		return carts;
		
	}
	
	public void addCartItem(Cart cart) {
		cartRepository.save(cart);
	}
	
	public void deleteCart(int cartId) {
		cartRepository.deleteById(cartId);
	}

}
