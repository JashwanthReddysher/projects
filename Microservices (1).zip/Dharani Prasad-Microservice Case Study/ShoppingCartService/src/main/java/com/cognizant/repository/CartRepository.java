package com.cognizant.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.model.Cart;

@Repository
@Transactional
public interface CartRepository extends JpaRepository<Cart, Integer> {
	
	@Query(value="select * from cart where user_id=?1",nativeQuery = true)
	public List<Cart> getCartItems(int userId);
	
	@Query(value="select * from cart where user_id=?1 and product_id=?2",nativeQuery = true)
	public Cart findCartExistByUserId(int userId,int productId);
	
	@Modifying
	@Query(value="delete from cart where user_id=?1 and product_id=?2",nativeQuery = true)
	public void deleteCart(int userId,int productId);
	
	@Modifying
	@Query(value="delete from cart where user_id=?1",nativeQuery = true)
	public void deleteByUserId(int userId);

	@Query(value="select * from cart where product_id=?1",nativeQuery = true)
	public Cart findByProductId(int productId);
	
//	@Query(value="delete from cart where user_id=?1 and product_id=?2",nativeQuery = true)
//	public void deleteCartItem(int userId,int productId);
	

}
