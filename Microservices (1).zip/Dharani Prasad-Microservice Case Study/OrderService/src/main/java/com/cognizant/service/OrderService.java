package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.model.Cash;
import com.cognizant.repository.OrderRepository;

@Service
@Transactional
public class OrderService {
	
	private OrderRepository orderRepository;

	public OrderService(OrderRepository orderRepository) {
		super();
		this.orderRepository = orderRepository;
	}
	
	public List<Cash> getOrderItems(){
		List<Cash> orders = new ArrayList<Cash>();
		for(Cash order : orderRepository.findAll()) {
			orders.add(order);
		}
		
		return orders;
		
	}
	
	public boolean addOrder(Cash order) {
		Cash o=orderRepository.save(order);
		if(o!=null) {
			return true;
			
		}
		return false;
	}

}
